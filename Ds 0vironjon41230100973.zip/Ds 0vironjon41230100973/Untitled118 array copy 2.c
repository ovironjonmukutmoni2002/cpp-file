#include<stdio.h>
int main()
{
    int a1[]={1,2,3,4,5},a2[5],i;
    printf("Array1 ");
    for(i=0;i<5;i++)
        printf("%d ",a1[i]);
        printf("\n");
    for(i=0;i<5;i++)
    {
        a2[i]=a1[i];
    }
    printf("Array2 ");
    for(i=0;i<5;i++)
    {
        printf("%d ",a2[i]);
    }
}
