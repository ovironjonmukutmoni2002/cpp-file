#include<stdio.h>
int main()
{
    char s1[]="My name is ";
    char s2[]="Trisha Barua";
    int i=0,len=0,j=0;
    while(s1[i]!='\0')
    {
        i++;
        len++;
    }
    while(s2[j]!='\0')
    {
        s1[len+j]=s2[j];
        j++;
    }
    printf("%s\n",s1);


    /*int a[3][3],b[3][3],rsum[3][3]= {0},csum[3][3]= {0},r,c,i,j,s[5][5]={0};
    char s1[5];//1 no string
    s1[0]='M';
    s1[1]='i';
    s1[2]='t';
    s1[3]='u';
    s1[4]='\0';
    char s2[6]={'S','e','t','u','\0'};
    char s3[]="Trisha Barua";
    printf("string 1 = %s\n",s1);
    printf("string 2 = %s\n",s2);
    printf("string 3 = %s\n",s3);

    int i=0;//2 no string
    while(n[i]!='\0')
    {
        printf("%c\n",n[i]);
        i++;
    }

    char n[]="Trisha Barua";//3 no string
    int s = strlen(n);
    printf("Length : %d",s);

     char n[]="Trisha Barua";//4 no string
    int i=0,len=0;
    while(n[i]!='\0')
    {
        i++;
        len++;
    }
printf("length : %d",len);


     char source[]="C programming";//5 no string
   char target[20];
   strcpy(target,source);
   printf("Source string : %s\n",source);
   printf("Target string : %s\n",target);


     char str1[]="My name is ";//6 no string
   char str2[]="Trisha Barua";
   strcat(str1,str2);//concatenation of string
   printf("String 01 : %s\n",str1);
   printf("String 02 : %s\n",str2);

   char str3[]="I am read in ";
   strcat(str3,"3rd semester");
   printf("String 03 : %s\n",str3);


    printf("Enter the elements of A \n");
    for(i=0;i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            printf("Element %d %d =",i,j);
            scanf("%d",&a[i][j]);
        }
        printf("\n");
    }

    printf("A \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
            printf("% 2d",a[i][j]);
        printf("\n");
    }

    printf("Enter the elements of B \n");
    for(i=0; j<2; i++)
    {
        for(j=0; j<2; j++)
        {
            printf("Element %d %d =",i,j);
        scanf("%d",&b[i][j]);
        }
    printf("\n");
    }
    printf("B \n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
            printf("% 2d",b[i][j]);
        printf("\n");
    }

     for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
          s[i][j]=a[i][j]+b[i][j];
    }

    printf("\n A+B =");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
            printf("% 2d",s[i][j]);
        printf("\n");
    }
    */

    return 0;
}
