#include<stdio.h>
int main()
{
    int a[]={5,8,3,9,2},n;
    printf("Enter number want to find ");
    scanf("%d",&n);
    int pos=-1,i;
    for(i=0;i<5;i++)
    {
      if(n==a[i])
      {
          pos=i+1;
            break;
      }
    }
    if(pos==-1)
        printf("Number not find ");
    else
        printf("The value %d position at %d",n,pos);
}
