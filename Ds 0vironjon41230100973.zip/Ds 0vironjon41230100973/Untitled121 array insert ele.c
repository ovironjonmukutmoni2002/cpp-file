#include<stdio.h>
int main()
{
    int a[100],size,pos,i,value;
    printf("Enter the size of array : ");
    scanf("%d",&size);
    printf("Enter the element of array");
    printf("\n");
    for(i=0; i<size; i++)
    {
        printf("Element [%d] : ",i);
        scanf("%d",&a[i]);
    }
    printf("\n");
    printf("Array : ");
    for(i=0; i<size; i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");

    printf("Give the position you want to insert : ");
    scanf("%d",&pos);
    printf("\n");

    printf("Give the value you want : ");
    scanf("%d",&value);
    printf("\n");

    for(i=size; i>pos-1; i--)
    {
        a[i]=a[i-1];
    }
    a[pos]=a[pos-1];

    printf("Final array : ");
    for(i=0; i<=size; i++)
    {
        printf("%d ",a[i]);
    }

    return 0;
    getch();
}
