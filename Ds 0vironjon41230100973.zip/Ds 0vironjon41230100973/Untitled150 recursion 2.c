#include<stdio.h>
int sum(int n)
{
    if(n==0)
    {
        return n;
    }
    return sum(n-1)+n;
}
int main()
{
    printf("%d",sum(9));
}

